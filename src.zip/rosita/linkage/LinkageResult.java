package rosita.linkage;

public class LinkageResult {
	public int intTotalQty;
	public int intMatchQty;
	public int intNonMatchQty;
	public int intTime;
	public String strMessage;
}
