package rosita.linkage.tests;

import java.util.ArrayList;
import rosita.linkage.tests.controller.NickNameController;
import rosita.linkage.tests.dao.NickNameDAO;
import rosita.linkage.tests.pojo.VoterData;

public class NickNameGeneratorTest {
	
	final static boolean Modification_TRUE = true;
	final static boolean Modification_FALSE = false;
	
	public static void main(String[] args) {
		
		// the rate for modification of rows including nicknames
		final double RATEOFCHANGE = 0.1;
		// the option for modifying each nickname, or not
		
		final String SCHEMA = "rosita.tz.";
		final String TABLE_NAME_A = SCHEMA + "a_link_dmv_voter_nickname";
		final String TABLE_NAME_B = SCHEMA + "b_link_dmv_voter_nickname";
				
		NickNameController nnCtrl = new NickNameController(RATEOFCHANGE);
		
		try {
			
			ArrayList<VoterData> listA = nnCtrl.readVoterData(Modification_TRUE); 
			ArrayList<VoterData> listB = nnCtrl.readVoterData(Modification_TRUE); 
			
			//1. Create dataset A
			nnCtrl.generateNickNameData(listA);
			nnCtrl.createNickNameData(TABLE_NAME_A, listA);
			
			//2. Create dataset B			
			nnCtrl.generateNickNameData(listB);			
			nnCtrl.createNickNameData(TABLE_NAME_B, listB);			
			
			System.out.println("TestDataGenerator is End");	
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
}