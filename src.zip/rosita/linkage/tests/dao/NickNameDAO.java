package rosita.linkage.tests.dao;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.DatabaseMetaData;
import java.util.ArrayList;
import java.util.HashMap;

import rosita.linkage.tests.pojo.VoterData;

public class NickNameDAO {

	public Connection getDBConnection() throws Exception {
		System.out.println("-------- PostgreSQL JDBC Connection Testing ------------");
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Where is your PostgreSQL JDBC Driver? "
					         + "Include in your library path!");
			throw e;
		}

		System.out.println("PostgreSQL JDBC Driver Registered!");
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:postgresql://localhost:5432/rosita", "admin", "admin");

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			throw e;
		}

		if (connection != null) {
			System.out.println("You made it, take control your database now!");
		} else {
			System.out.println("Failed to make connection!");
		}
		
		return connection;
	}	
	
	public HashMap readSingleNickNamesFromDB(Connection con) throws Exception {
		Statement st = null;
        ResultSet rs = null;
        HashMap<String, String> hmap = new HashMap<String, String>();
        
        String sql =  "SELECT firstname, string_agg(nickname, ',') as nickname \n"
        		    + "FROM tz.single_nickname \n"
        		    + "group by firstname \n";
        
        try {
	        st = con.createStatement();
	        rs = st.executeQuery(sql);
	        
	        while (rs.next()) {
	        	String firstName = rs.getString(1).trim().toUpperCase();
	        	String nickName = rs.getString(2).trim().toUpperCase();
	            //System.out.println("firstname=" + firstName + ", nickname=" + nickName );
	            hmap.put(firstName, nickName);
	        }
	        
        } catch (SQLException e) {
        	throw e;
        } finally {
            if (rs != null) rs.close();
            if (st != null) st.close();
        }
        
        return hmap;
	}
	
	public HashMap readMultiNickNamesFromDB(Connection con) throws Exception {
		Statement st = null;
        ResultSet rs = null;
        HashMap<String, String> hmap = new HashMap<String, String>();
        
        String sql =  "SELECT firstname, nickname \n"
        		    + "FROM tz.multi_nickname \n";
        
        try {
	        st = con.createStatement();
	        rs = st.executeQuery(sql);
	        
	        while (rs.next()) {
	        	String firstName = rs.getString(1).trim().toUpperCase();
	        	String nickName = rs.getString(2).trim().toUpperCase();
	            //System.out.println("firstname=" + firstName + ", nickname=" + nickName );
	            hmap.put(firstName, nickName);
	        }
	        
        } catch (SQLException e) {
        	throw e;
        } finally {
            if (rs != null) rs.close();
            if (st != null) st.close();
        }
        
        return hmap;
	}	
	
	public ArrayList readVoterDataFromDB(Connection con, boolean isModification) throws Exception {
		Statement st = null;
        ResultSet rs = null;
        ResultSet rs1 = null;
        ArrayList list = new ArrayList();
        
        String sql =  "SELECT id, county_cd, first_name, last_name, middle_name, name_suffix_lbl, res_addr1, res_addr2, res_state, res_city, res_zip, res_zip4, race_cd, ethnic_cd, gender_cd, age, party_cd, dmv_timestamp \n"
   			        + "FROM tz.nc_dmv_voter \n";        
        
        try {
	        st = con.createStatement();
	        rs = st.executeQuery(sql);
	        
	        while (rs.next()) {
	        	VoterData voter = new VoterData(isModification);
	        	
	        	voter.setId(rs.getInt(1));
	        	voter.setCountyCd(rs.getString(2).trim());
	        	voter.setFirstName(rs.getString(3).trim().toUpperCase());
	        	voter.setLastName(rs.getString(4).trim());
	        	voter.setMiddleName(rs.getString(5).trim());
	        	voter.setNameSuffixLbl(rs.getString(6).trim());
	        	voter.setResAddr1(rs.getString(7).trim());
	        	voter.setResAddr2(rs.getString(8).trim());
	        	voter.setResState(rs.getString(9).trim());
	        	voter.setResCity(rs.getString(10).trim());
	        	voter.setResZip(rs.getString(11).trim());
	        	voter.setResZip4(rs.getString(12).trim());
	        	voter.setRaceCd(rs.getString(13).trim());
	        	voter.setEthnicCd(rs.getString(14).trim());
	        	voter.setGenderCd(rs.getString(15).trim());
	        	voter.setAge(rs.getInt(16));
	        	voter.setPartyCd(rs.getString(17).trim());
	        	voter.setDmvTimestamp(rs.getDate(18));        	
	        	
	        	list.add(voter);
	        }
	        
        } catch (SQLException e) {
        	throw e;
        } finally {
            if (rs != null) rs.close();
            if (st != null) st.close();
        }
        return list;
	}
	
	public boolean checkTableExist(Connection con, String tableName) throws Exception {
		boolean isExist = false;
	    try {
	    	DatabaseMetaData meta = con.getMetaData();
	    	ResultSet tables = meta.getTables(null, null, tableName, null);
	    	if (tables.next()) {
	    		isExist = true;
	    	}
	    } catch (SQLException e) {
        	throw e;
        }	
	    return isExist;		
	}	
	
	public void dropTestNickNameTable(Connection con, String tableName) throws Exception {
	    Statement st = null;
	    try {
	    	st = con.createStatement();
	        String sql = "DROP TABLE " + tableName;   
System.out.println("Drop sql=" + sql);	        
	        st.executeUpdate(sql);
	        st.close();	    	
	    } catch (SQLException e) {
        	throw e;
        } finally {
            if (st != null) st.close();
        }
	}	
	
	public void createTestNickNameTable(Connection con, String tableName) throws Exception {
	    Statement st = null;
	    try {
	    	st = con.createStatement();
	        String sql = "CREATE TABLE " + tableName +
	                "(                                      "+
	                "  id integer NOT NULL,                 "+
	                "  county_cd text NOT NULL,             "+
	                "  first_name  text NOT NULL,            "+
	                "  last_name text NOT NULL,              "+
	                "  middle_name text NULL,                "+
	                "  name_suffix_lbl text NULL,            "+
	                "  res_addr1 text NULL,                  "+
	                "  res_addr2 text NULL,                  "+
	                "  res_state text NULL,                  "+
	                "  res_city text NULL,                   "+
	                "  res_zip text NULL,                    "+
	                "  res_zip4 text NULL,                   "+
	                "  race_cd text NULL,                    "+
	                "  ethnic_cd text NULL,                  "+
	                "  gender_cd text NULL,                  "+
	                "  age integer NULL,                     "+
	                "  party_cd text NULL,                   "+
	                "  dmv_timestamp date NULL,              "+
	                "  nick_name text NULL                   "+	                
	                ")                                      ";   	
	        st.executeUpdate(sql);
	        st.close();	    	
	    } catch (SQLException e) {
        	throw e;
        } finally {
            if (st != null) st.close();
        }
		
	}	
	
	public void insertTestNickNameData(Connection con, String tableName, VoterData voter) throws Exception {
		PreparedStatement pstmt = null;
	    try {
	    	 String sql = "INSERT INTO " + tableName + " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	    	 pstmt = con.prepareStatement(sql);
	    	 
	         pstmt.setInt(1, voter.getId());
	    	 pstmt.setString(2, voter.getCountyCd());
	         pstmt.setString(3, voter.getFirstName());
	         pstmt.setString(4, voter.getLastName());
	         pstmt.setString(5, voter.getMiddleName());
	         pstmt.setString(6, voter.getNameSuffixLbl());
	         pstmt.setString(7, voter.getResAddr1());
	         pstmt.setString(8, voter.getResAddr2());
	         pstmt.setString(9, voter.getResState());
	         pstmt.setString(10, voter.getResCity());
	         pstmt.setString(11, voter.getResZip());
	         pstmt.setString(12, voter.getResZip4());
	         pstmt.setString(13, voter.getRaceCd());
	         pstmt.setString(14, voter.getEthnicCd());
	         pstmt.setString(15, voter.getGenderCd());
	         pstmt.setInt(16, voter.getAge());
	         pstmt.setString(17, voter.getPartyCd());
	         pstmt.setDate(18, voter.getDmvTimestamp());
	         pstmt.setString(19, voter.getUpdatedNickName());      	

	         pstmt.executeUpdate();	    	
	    	
	    } catch (SQLException e) {
        	throw e;
        } finally {
            if (pstmt != null) pstmt.close();
        }
		
	}

}
