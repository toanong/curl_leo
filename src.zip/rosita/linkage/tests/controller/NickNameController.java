package rosita.linkage.tests.controller;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

import rosita.linkage.tests.dao.NickNameDAO;
import rosita.linkage.tests.pojo.VoterData;

public class NickNameController {
	double rateOfchange = 0;

	public NickNameController(double rateOfchange) {
		this.rateOfchange = rateOfchange;		
	}

	public ArrayList<VoterData> readVoterData(boolean isModification) throws Exception {
		
		Connection con = null;
		NickNameDAO nnDao = new NickNameDAO();
		ArrayList<VoterData> list = new ArrayList<VoterData>();
		
		try {

			con = nnDao.getDBConnection();

			HashMap<String, String> sHmap = nnDao.readSingleNickNamesFromDB(con);
			HashMap<String, String> mHmap = nnDao.readMultiNickNamesFromDB(con);

			// for (String value : sHmap.values()) {
			// System.out.println("1" + value);
			// }

			// for (String value : mHmap.values()) {
			// System.out.println("2" + value);
			// }

			// for (String value : hmap.values()) {
			// System.out.println(value);
			// }

			list = nnDao.readVoterDataFromDB(con, isModification);
			
			for (VoterData v : list) {
				String fn = v.getFirstName();
				// System.out.println("fn=" + fn);
				if (mHmap.containsKey(fn)) {
					String nn = mHmap.get(fn);
					v.setNickName(nn);
					// System.out.println("m_fn=" + fn + ",nn=" + nn);
				} else if (sHmap.containsKey(fn)) {
					String nn = sHmap.get(fn);
					v.setNickName(nn);
					// System.out.println("s_fn=" + fn + ",nn=" + nn);
				} else {
					v.setNickName("");
				}
			}
		} catch (Exception e) {
			throw e;
		} finally {
			con.close();
		}
		
		return list;
	}

	public void generateNickNameData(ArrayList<VoterData> list) {
		int iUpdatedNickName = 0;
		int iOriginalNickName = 0;
		double currentRatio = 0;

		for (VoterData v : list) {
			String orgNickName = v.getNickName();
			currentRatio = (double) iUpdatedNickName / list.size();
			if (orgNickName.length() > 0) {
				if (currentRatio <= this.rateOfchange) {
					String newNickName = v.generateUpdatedNickNames();
					//System.out.println("Random:FN=" + v.getFirstName() + ":OrgNN=" + v.getNickName() + ":NewNN=" + newNickName);
					v.setUpdatedNickName(newNickName);
					++iUpdatedNickName;
				} else {
					//System.out.println("FN=" + v.getFirstName() + ":NN="+ v.getNickName());
					v.setUpdatedNickName(orgNickName);
					++iOriginalNickName;					
				}
			}
		}
		System.out.println("TotalSize=" + list.size());
		System.out.println("iUpdatedNickName=" + iUpdatedNickName);
		System.out.println("iOriginalNickName=" + iOriginalNickName);
		System.out.println("RatioOfRandomNicNames=" + currentRatio);
	}

	public void createNickNameData(String tableName, ArrayList<VoterData> list) throws Exception {
		Connection con = null;
		NickNameDAO nnDao = new NickNameDAO();
		try {
			con = nnDao.getDBConnection();
			
//			if(nnDao.checkTableExist(con, tableName)) {
//				nnDao.dropTestNickNameTable(con, tableName);
//			}
			
			nnDao.dropTestNickNameTable(con, tableName);
			
			nnDao.createTestNickNameTable(con, tableName);
			
			this.generateNickNameData(list);
			for (VoterData voter : list) {
				nnDao.insertTestNickNameData(con, tableName, voter);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			con.close();
		}

	}
}
