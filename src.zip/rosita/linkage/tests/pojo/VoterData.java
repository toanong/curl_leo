package rosita.linkage.tests.pojo;

import java.sql.Date;
import java.util.Random;
import java.util.StringTokenizer;

public class VoterData {
	final String DELIMETER = ",";	
	boolean isModification = false;
	
	public VoterData() {
	}
	
	public VoterData(boolean isModification) {
		this.isModification = isModification;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCountyCd() {
		return countyCd;
	}
	public void setCountyCd(String countyCd) {
		this.countyCd = countyCd;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getNameSuffixLbl() {
		return nameSuffixLbl;
	}
	public void setNameSuffixLbl(String nameSuffixLbl) {
		this.nameSuffixLbl = nameSuffixLbl;
	}
	public String getResAddr1() {
		return resAddr1;
	}
	public void setResAddr1(String resAddr1) {
		this.resAddr1 = resAddr1;
	}
	public String getResAddr2() {
		return resAddr2;
	}
	public void setResAddr2(String resAddr2) {
		this.resAddr2 = resAddr2;
	}
	public String getResState() {
		return resState;
	}
	public void setResState(String resState) {
		this.resState = resState;
	}
	public String getResCity() {
		return resCity;
	}
	public void setResCity(String resCity) {
		this.resCity = resCity;
	}
	public String getResZip() {
		return resZip;
	}
	public void setResZip(String resZip) {
		this.resZip = resZip;
	}
	public String getResZip4() {
		return resZip4;
	}
	public void setResZip4(String resZip4) {
		this.resZip4 = resZip4;
	}
	public String getRaceCd() {
		return raceCd;
	}
	public void setRaceCd(String raceCd) {
		this.raceCd = raceCd;
	}
	public String getEthnicCd() {
		return ethnicCd;
	}
	public void setEthnicCd(String ethnicCd) {
		this.ethnicCd = ethnicCd;
	}
	public String getGenderCd() {
		return genderCd;
	}
	public void setGenderCd(String genderCd) {
		this.genderCd = genderCd;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPartyCd() {
		return partyCd;
	}
	public void setPartyCd(String partyCd) {
		this.partyCd = partyCd;
	}
	public Date getDmvTimestamp() {
		return dmvTimestamp;
	}
	public void setDmvTimestamp(Date dmvTimestamp) {
		this.dmvTimestamp = dmvTimestamp;
	}
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public void setUpdatedNickName(String updatedNickName) {
		this.updatedNickName = updatedNickName;
	}		
	public String getUpdatedNickName() {
		return this.updatedNickName;
	}	
	
	private String makeUpdatedNickName(String sOrg) {
		StringBuilder sNew = new StringBuilder(sOrg);
		String sNumber = "0123456789";
		int seed = 5;
		
	    int iIndexOnString = getRandomNumber(seed, sOrg.length());
	    int iIndexNumber = getRandomNumber(seed, sNumber.length());
	    
		//return True of False Randomly for replacement: Updating a char or Deleting a char
		if(this.randomBoolean()) {
			sNew.setCharAt(iIndexOnString, sNumber.charAt(iIndexNumber));
		} else {
			sNew.deleteCharAt(iIndexOnString);
		}
	    
	    //System.out.println("iIndexOnString=" + iIndexOnString + ":iIndexNumber=" + iIndexNumber + ":sOrg=" + sOrg + ",sNew=" + sNew.toString());
	    return sNew.toString();
	}
	
	private boolean randomBoolean(){
	    return Math.random() < 0.5;
	}
	
	private int getRandomNumber(int seed, int upperbound) {
	    Random rand = new Random(seed);		
	    int i = upperbound - rand.nextInt(upperbound);
	    return i;
	}

	public String generateUpdatedNickNames() {
		StringBuffer newNickName = new StringBuffer();
		String changedNickName = "";
		boolean isFirst = true;
		
		StringTokenizer st = new StringTokenizer(this.nickName, this.DELIMETER);
		
		while(st.hasMoreElements()) {
			String nickName = ((String)st.nextElement()).trim();
			
			//return True of False Randomly for inclusion
			if(this.randomBoolean()) {
				
				if(this.isModification) {
					//return True of False Randomly for modification
					if(this.randomBoolean()) changedNickName = this.makeUpdatedNickName(nickName);
					else changedNickName = nickName;
	
					if(!isFirst) newNickName.append(",");
					newNickName.append(changedNickName);
					isFirst = false;
				} else {
					changedNickName = nickName;
					
					if(!isFirst) newNickName.append(",");
					newNickName.append(changedNickName);
					isFirst = false;
				}
			} else {
				continue;
			}
		}
		
		return newNickName.toString();
	}
	
	int id = 0;
	String countyCd = "";
	String firstName = "";
	String lastName = "";
	String middleName = "";
	String nameSuffixLbl = "";
	String resAddr1 = "";
	String resAddr2 = "";
	String resState = "";
	String resCity = "";
	String resZip = "";
	String resZip4 = "";
	String raceCd = "";
	String ethnicCd = "";
	String genderCd = "";
	int age = 0;
	String partyCd = "";
	Date dmvTimestamp = null;
	String nickName = "";
	String updatedNickName = "";
	
	int numNormalNN = 0;
	int numUpdatedNNByReplacement = 0;
	int numUpdatedNNByDeletion = 0;

	char randomChar = '\0';
}
