package rosita.linkage.analysis;

public enum MultiMode 
{
	N_1,
	N_DATASET1,
	N_DATASET2,
	N_K_DATASET1,
	N_K_AVERAGE,
	NONE;
	
	static public boolean isMember(MultiMode aName) {
		MultiMode[] aWIs = MultiMode.values();
       for (MultiMode aWI : aWIs)
           if (aWI.equals(aName))
               return true;
       return false;
    }
}
