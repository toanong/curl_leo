package rosita.linkage.tools.cic;

public class BackupField {
	public String FieldName;
	public int Value;
	
	public BackupField(){
		
	}
}
