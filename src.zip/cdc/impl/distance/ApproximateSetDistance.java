/* ***** BEGIN LICENSE BLOCK *****
 * Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is the FRIL Framework.
 *
 * The Initial Developers of the Original Code are
 * The Department of Math and Computer Science, Emory University and 
 * The Centers for Disease Control and Prevention.
 * Portions created by the Initial Developer are Copyright (C) 2008
 * the Initial Developer. All Rights Reserved.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

package cdc.impl.distance;

import java.awt.Dimension;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.commons.collections.map.HashedMap;

import cdc.components.AbstractDistance;
import cdc.components.AbstractStringDistance;
import cdc.datamodel.DataCell;
import cdc.datamodel.DataColumnDefinition;
import cdc.utils.Log;
import cdc.utils.RJException;
import rosita.linkage.MappedPair;
import rosita.linkage.analysis.Algorithm;
import rosita.linkage.analysis.PPRLDistance;
import rosita.linkage.analysis.NONEDistance;

public class ApproximateSetDistance extends AbstractStringDistance {

	private static final int logLevel = Log.getLogLevel(ApproximateSetDistance.class);

	public static final String DEFAULT_DELIMITER = ",";
	public static final String STR1_SET = "STR1_SET";
	public static final String STR2_SET = "STR2_SET";

	private MappedPair parPair = null;
	public AbstractDistance adistance = null;	
	
	public static Algorithm parAlgorithm = null;
	public int multiMode = 0;
	public double defaultThresholdLevel = 0.9;
	
	private static double dblPPRLThreshold = 0;
	
	public ApproximateSetDistance() {
		super(null);
	}
	
	public ApproximateSetDistance(Map props, Algorithm a, int multimode, double defaultThresholdLevel, AbstractDistance ad) {
		super(props);
		this.parAlgorithm = a;
		this.multiMode = multimode;
		this.defaultThresholdLevel = defaultThresholdLevel;		
		this.adistance = ad;		
	}	

	public ApproximateSetDistance(Map props, Algorithm a, int multimode, double defaultThresholdLevel) {
		super(props);
		this.parAlgorithm = a;
		this.multiMode = multimode;
		this.defaultThresholdLevel = defaultThresholdLevel;		
		this.adistance = this.determineAlgorithm();
	}

	public static AbstractDistance determineAlgorithm() {
		Map props = new HashedMap();
		AbstractDistance adistance = null;		

		if (parAlgorithm.equals(Algorithm.EQUAL_FIELDS_BOOLEAN_DISTANCE)){
			adistance = new EqualFieldsDistance(props);
		}
		else if(parAlgorithm.equals(Algorithm.EDIT_DISTANCE)){ 
			props.put(EditDistance.PROP_BEGIN_APPROVE_LEVEL, "0.2");
			props.put(EditDistance.PROP_END_APPROVE_LEVEL, "0.4");
			adistance = new EditDistance(props);
		}
		else if(parAlgorithm.equals(Algorithm.JARO_WINKLER)){ 
			props.put("pref-length", "4");
			props.put("pref-weight", "0.1");
			adistance = new JaroWinkler(props);
		}
		
//		else if(parAlgorithm.equals(Algorithm.DATE_DISTANCE)){
//			if(parPair.getDateFormatA()!=null && parPair.getDateFormatB()!=null){
//				props.put(DateDistance.PROP_FORMAT1 , parPair.getDateFormatA());
//				props.put(DateDistance.PROP_FORMAT2, parPair.getDateFormatB());
//				adistance = new DateDistance(props);
//			}else{
//				//TODO: Throw exception
//			}	
//		}
		
		else if(parAlgorithm.equals(Algorithm.ADDRESS_DISTANCE)){
			props.put(AddressDistance.PROP_BEGIN_APPROVE_LEVEL, "0.0");
			props.put(AddressDistance.DEFAULT_END_APPROVE_LEVEL, "0.3");
			props.put("resolve-secondary-location", "true");
			adistance = new AddressDistance(props);
		}
		else if(parAlgorithm.equals(Algorithm.QGRAM_DISTANCE)){
			props.put("q", "3");
			props.put(QGramDistance.PROP_DISAPPROVE, "0.4");
			props.put(QGramDistance.PROP_APPROVE, "0.2");
			adistance = new QGramDistance(props);
		}
		else if(parAlgorithm.equals(Algorithm.SOUNDEX_DISTANCE)){
			props.put("soundex-length", "5");
			props.put("match-level-start", "0");
			props.put("math-level-end", "0");
			adistance = new SoundexDistance(props);
		} else if(parAlgorithm.equals(Algorithm.PPRL)){
			adistance = new PPRLDistance(dblPPRLThreshold);
		}else if(parAlgorithm.equals(Algorithm.NONE)){
			adistance = new NONEDistance();
		}
		
		return adistance;
	}

	private double getApproximateDistance(String s1, HashMap hstr2) {
		double result = 0;
		// String prop = getProperty(PROP_COMPARISON_LEVEL);
		// System.out.println("PROP_COMPARISON_LEVEL_Prop=" + prop);
//System.out.println("s1= " + s1);

		if (parAlgorithm == Algorithm.EQUAL_FIELDS_BOOLEAN_DISTANCE) {
			if (hstr2.containsKey(s1)) result = 100;
			else result = 0;
//System.out.println("1. ApproximateDistance-Deterministic_mode, s1=" + s1 + " hstr2=" + hstr2.toString() + " distance=" + result);			
		} else {
//System.out.println("Row:Probabilistic_mode");
			Iterator itr = hstr2.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry d1 = (Map.Entry) itr.next();
				String s2 = d1.getKey().toString();
//System.out.println("s1=" + s1 + " s2=" + s2);
//System.out.println("parAlgorithm=" + parAlgorithm);
				double d = adistance.distance(s1, s2);
//System.out.println("1-1. s1=" + s1 + ", s2=" + s2 + ", Distance of distance method=" + d);				
				/**
				 * The threshold should use for edit distance method
				 * To do: define different threshold for different distance methods 
				 */
//				if (parAlgorithm == Algorithm.EDIT_DISTANCE) {
					d = d > this.defaultThresholdLevel*100 ? 100 : 0;
//				}
//System.out.println("s1=" + s1 + " s2=" + s2 + " algorith=" + this.parAlgorithm + " distance=" + d);
				result += d;
			}

			// Getting average of results
		}
		return result;
	}
	
	public double distance(String str1, String str2) {
		double distEStr1=0; 
		double distStr1=0;
		double finalDist=0;

		if (str1.contains(this.DEFAULT_DELIMITER)||str2.contains(this.DEFAULT_DELIMITER)){
			Map dataset = getTokenizedData(str1, str2);
			HashMap hstr1 = (HashMap) dataset.get(STR1_SET);
			HashMap hstr2 = (HashMap) dataset.get(STR2_SET);
	
			//While a in Multi-string A
			Iterator itr = hstr1.entrySet().iterator();
			while (itr.hasNext()) {
				Map.Entry d1 = (Map.Entry) itr.next();
				String e_str1 = d1.getKey().toString();
	//System.out.println("distanceMultiValue:s1=" + s1);
				distEStr1 = getApproximateDistance(e_str1, hstr2);
//System.out.println("1-2. Calculating the sum of distances on element:" + e_str1 + ", String B=" + hstr2.toString() + ", Sum of distance of " + e_str1 + "=" + distEStr1 + "\n");				
				distStr1 += distEStr1;
			}			
System.out.println("2. Calculating the sum of distances on string:" + str1 + ", Sum of distances=" + distStr1);			

			finalDist = this.getDistanceByMultimode(distStr1, hstr1.size(), hstr2.size());		
		}else{
			finalDist = adistance.distance(str1, str2);
		}
		
System.out.println("4.[ASD]FinalDist=" + finalDist + " [A]=" + str1 + " [B]=" + str2 + " Distance=" + distStr1 + " multimode=" + multiMode);			
		return finalDist;
	}

	public double distance(DataCell cell1, DataCell cell2) {
		String str1 = cell1.getValue().toString();
		String str2 = cell2.getValue().toString();
//System.out.println("str1=" + str1 + " str2=" + str2);		
		return distance(str1, str2);
	}
	
	/**
	 * Select multimode: 1, 2, 3, 4, 5
	 * @param sumDistA
	 * @param sumDistB
	 * @param sizeDataA
	 * @param sizeDataB
	 * @return
	 */
	private double getDistanceByMultimode(double sumDistStr1, int sizeStr1, int sizeStr2) {
		double result = 0;
		double value = sumDistStr1/100;
//System.out.println("3-1. Sum of Distance of String A=" + sumDistStr1 + ", Value=" + value + ", Elements # of String A=" + sizeStr1 + ", Elements # of String B=" + sizeStr2);		
		if (multiMode == 1){
			result = value >= 1 ? 100 : 0;
		} else if (multiMode == 2){
			result = value == sizeStr1 ? 100 : 0;
		} else if (multiMode == 3){
			result = value == sizeStr2 ? 100 : 0;
		} else if (multiMode == 4){
			result = (double)value/(double)sizeStr1*100;
		} else if (multiMode == 5){
			double avgSize = (double)(sizeStr1 + sizeStr2)/2.0;
			result = value/avgSize*100;
		}
//System.out.println("3-2. Calculating distance By Multimode=" + multiMode  + ", Algorithm=" + parAlgorithm + ", Sum of Distance of String A=" + sumDistStr1 + ", FinalDistance=" + result);		
		return result;
	}

//	private double distanceMultiValue(HashMap hstr1, HashMap hstr2) {
//		double value = 0;
//		int num=0;
//		
//		Iterator itr = hstr1.entrySet().iterator();
//		//While a in Multi-string A
//		while (itr.hasNext()) {
//			Map.Entry d1 = (Map.Entry) itr.next();
//			String s1 = d1.getKey().toString();
////System.out.println("distanceMultiValue:s1=" + s1);
//			double distance = ApproximateDistance(s1, hstr2);
//			
//			value += distance;
////System.out.println("s1=" + s1 + ", s2=" + hstr2.toString() + ", distance=" + distance);
//		}
//		return value;
//	}

	public Map getTokens(String line) {
		int i = 0;
		HashMap<String, Integer> tokens = new HashMap();
		StringTokenizer st = new StringTokenizer(line, this.DEFAULT_DELIMITER);
		while (st.hasMoreTokens()) {
			String s = st.nextToken();
			// System.out.println(s);
			tokens.put(s.trim().toUpperCase(), i);
		}
		return tokens;
	}

	public Map getTokenizedData(String s1, String s2) {
		Map dataset = new HashMap();
		dataset.put(STR1_SET, getTokens(s1));
		dataset.put(STR2_SET, getTokens(s2));
		return dataset;
	}
	
	public String toString() {
		return "ApproximateSet distance " + getProperties();
	}	

	public void setParAlgorithm(Algorithm a) {
		this.parAlgorithm = a;
	}
	
	public Algorithm getParAlgorithm() {
		return parAlgorithm;
	}
	
	public static void main(String[] args) {
		Map props = new HashMap();
		int multiMode = 5;
		double defaultThresholdLevel = 0.9;
		ApproximateSetDistance asd = new ApproximateSetDistance(props, Algorithm.EDIT_DISTANCE, multiMode, defaultThresholdLevel);
		
		
//		String str1 = "555 S Allison Pkwy|521 S Allison Pkwy", str2 = "512 S Allison Pkwy|12043 W Alameda Pkwy";
//		String str3 = "421 S Allison Pkwy|521 S Allison Pkwy", str4 = "555 S Allison Pkwy|421 S Allison Pkwy";		
		
//		String str1 = "08072017|01072017", str2 = "07072017|08072017";
//		String str3 = "04072017|03072017", str4 = "04072017|04072017";
		
//		String str1 = "ADam|Sith|S", str2 = "Adam|SithRobert|K";
		//String str1 = "M3RIAL,MAR3A,MARYA,MAYA", str2 = "M3RIKA,MARJA,MAYRA";
//		String str1 = "HARY", str2 = "HAL,HAR3Y";
		String str1 = "LIN,L3NDEY,LINDY,LINN,LYNA,LYNDY,LYNNE,LYNNDA,LYNNDIE", str2 = "LIN3I,L3NDIE,LINY,LIN,LYN3A,LYNY,LN,LY3N,LYNNE";
		
		asd.distance(str1, str2);
		//System.out.println("Total Distance Case#2=" + asd.distance(str3, str4));		
	}
}
